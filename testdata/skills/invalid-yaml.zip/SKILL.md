---
name: Test Skill
description: A test skill
invalid yaml: [unclosed
---

# Test Skill
